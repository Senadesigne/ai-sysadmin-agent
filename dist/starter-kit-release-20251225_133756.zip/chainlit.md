# Welcome to AI SysAdmin Agent

This agent helps you manage your hardware infrastructure.

## Features
- **Inventory Management**: Query your hardware inventory.
- **RAG Documentation**: Ask questions about technical manuals.
- **Configuration**: Generate safe CLI commands.
